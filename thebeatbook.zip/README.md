# react-starter
Simple Boilerplate for React Project

## To start the app

`npm install -g webpack`

`npm install`

`npm run react-dev`

`npm run server-dev`
